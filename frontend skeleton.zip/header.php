<link rel="stylesheet" href="css/header.css">

<nav class="navbar">
    <ul>
        <li><a href="signup.php">Sign Up</a></li>
        <li><a href="login.php">Login</a></li>  
        <li><a href="wishlist.php">Wishlist</a></li>
        <li><a href="products.php">Products</a></li>
        <li><a href="dashboard.php">Manager Dashboard</a></li>   
        <li><a href="customerDashboard.php">Customer Dashboard</a></li>   
    </ul>
</nav>

<!-- <hr> -->

